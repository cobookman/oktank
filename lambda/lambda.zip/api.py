
import sys
import logging
import rds_config
from lib.pymysql import pymysql

rds_name = "admin"
rds_pass = "Kv3FwnWFk0Xh1z7HJnJH"
rds_host = "octank-fashion-db-cluster.cluster-cbeb0qpdwkyx.us-west-1.rds.amazonaws.com"
db_name = "events"

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()
logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")


def handler(event, context):
  """Takes in shopping event, pushes to Aurora."""
  message = 'Hello {} {}!'.format(event['first_name'], 
                                  event['last_name'])  

  cur.execute("create table Employee ( EmpID  int NOT NULL, Name varchar(255) NOT NULL, PRIMARY KEY (EmpID))")
  cur.execute('insert into Employee (EmpID, Name) values(1, "Joe")')
  cur.execute('insert into Employee (EmpID, Name) values(2, "Bob")')
  cur.execute('insert into Employee (EmpID, Name) values(3, "Mary")')
  conn.commit()
  cur.execute("select * from Employee")
  for row in cur:
      item_count += 1
      logger.info(row)
      #print(row)
    conn.commit()

    return "Added %d items from RDS MySQL table" %(item_count)
  return { 
    'message' : message
  }  
